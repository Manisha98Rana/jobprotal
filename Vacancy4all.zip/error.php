<?php
include('header2.php');
?>
<div class="error-page">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="error-wrapper">
                    <div class="error-img">
                        <img class="img-fluid" src="image/404.svg" alt="">
                    </div>
                    <div class="error-content-area text-center">
                        <h2>Opps... Page Not Found</h2>
                        <p>Something went wrong, web page that is displayed to the user when the server cannot find the requested page.</p>
                        <div class="error-btn">
                            <a class="primry-btn-2 lg-btn " href="index.html">Back Homepage</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include('footer.php');
?>