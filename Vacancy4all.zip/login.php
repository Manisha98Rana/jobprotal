<?php   

 include_once('loginprocess.php');
    
 include('header.php'); ?> 
<div class="login-area pt-120 mb-120">
    <div class="container">		
        <div class="row">
        <?php include('errors.php'); ?>
            <div class="col-lg-12">
                <div class="form-wrapper">
                    <div class="form-title">
                        <h3>Log In Here!</h3>
                        <span></span>
                    </div>

                    <form action="login.php" method="POST">

                    <?php 
                    // If form submitted, collect email and password from form
                        // if (isset($_POST['login'])) {
                        //     $email    = $_POST['email'];
                        //     $password = $_POST['password'];

                        //     // Check if a user exists with given username & password
                        //     $result = mysqli_query($conn, "select 'email', 'password' from register
                        //         where email='$email' and password='$password'");

                        //     // Count the number of user/rows returned by query 
                        //     $user_matched = mysqli_num_rows($result);

                        //     // Check If user matched/exist, store user email in session and redirect to sample page-1
                        //     if ($user_matched > 0) {

                        //         $_SESSION["email"] = $email;
                        //         header("location: user-dashboard.php");
                        //     } else {
                        //         echo "User email or password is not matched <br/><br/>";
                        //     }
                        // }
                    ?>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="form-inner mb-25">
                                    <label for="email">Email*</label>
                                    <div class="input-area">
                                        <img src="image/email-2.svg" alt="">
                                        <input type="email" id="email" name="email" placeholder="info@example.com">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-inner">
                                    <label for="email">Password*</label>
                                    <input type="password" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" id="password" placeholder="Password" />
                                    <i class="bi bi-eye-slash" id="togglePassword"></i>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-agreement form-inner d-flex justify-content-between flex-wrap">
                                    <div class="form-group">
                                        <input type="checkbox" id="html">
                                        <label for="html">Remember Me</label>
                                    </div>
                                    <a href="#" class="forgot-pass">Forget Password?</a>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-inner">
                                    <button class="primry-btn-2" name="login" type="submit">LogIn</button>
                                </div>
                            </div>
                            <h6>Don’t have an account? <a href="register.php">Sign Up</a></h6>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php 
include('footer2.php');
?>