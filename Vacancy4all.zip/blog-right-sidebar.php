<?php
include('header2.php');
?>
<div class="inner-banner">
<div class="container">
<div class="row">
<div class="col-lg-12">
<div class="banner-content text-center">
<h1>Blog Right Sidebar</h1>
<span></span>
<nav aria-label="breadcrumb">
<ol class="breadcrumb">
<li class="breadcrumb-item"><a href="home.php">Home</a></li>
<li class="breadcrumb-item active" aria-current="page">Blog Right Sidebar</li>
</ol>
</nav>
</div>
</div>
</div>
</div>
</div>


<div class="blog-right-sidebar-area pt-120 mb-120">
<div class="container">
<div class="row g-lg-4 gy-5 justify-content-center">
<div class="col-lg-8">
<div class="row g-lg-4 gy-5 justify-content-center">
<div class="col-md-6 col-sm-10 mb-20">
<div class="recent-article-wrap">
<div class="recent-article-img">
<img class="img-fluid" src="image/blog-img-01.png" alt="">
<div class="publish-area d-xl-none d-flex">
<a href="blog-right-sidebar.php"><span>02</span>March</a>
</div>
</div>
<div class="recent-article-content">
<div class="recent-article-meta">
<div class="publish-area">
<a href="blog-right-sidebar.php"><span>02</span>March</a>
</div>
<ul>
<li><a href="blog-right-sidebar.php"><img src="image/comment.svg" alt="">03 Comments</a></li>
<li><a href="blog-right-sidebar.php"><img src="image/user.svg" alt="">Mr. Jack Frank</a></li>
</ul>
</div>
<h4><a href="blog-details.php">To Make Your Smartness &amp; Catch
Your Bright Dream.</a></h4>
<div class="explore-btn">
<a href="blog-details.php"><span><img src="image/explore-elliose.svg" alt=""></span> Explore More</a>
</div>
</div>
</div>
</div>
<div class="col-md-6 col-sm-10 mb-20">
<div class="recent-article-wrap">
<div class="recent-article-img">
<img class="img-fluid" src="image/blog-img-02.png" alt="">
<div class="publish-area d-xl-none d-flex">
<a href="blog-right-sidebar.php"><span>04</span>March</a>
</div>
</div>
<div class="recent-article-content">
<div class="recent-article-meta">
<div class="publish-area">
<a href="blog-right-sidebar.php"><span>04</span>March</a>
</div>
<ul>
<li><a href="blog-right-sidebar.php"><img src="image/comment.svg" alt="">11 Comments</a></li>
<li><a href="blog-right-sidebar.php"><img src="image/user.svg" alt="">Mr. Jack Frank</a></li>
</ul>
</div>
<h4><a href="blog-details.php">Be Confident Your Dream & Struggle
About Your Bright Dream.</a></h4>
<div class="explore-btn">
<a href="blog-details.php"><span><img src="image/explore-elliose.svg" alt=""></span> Explore More</a>
</div>
</div>
</div>
</div>
<div class="col-md-6 col-sm-10 mb-20">
<div class="recent-article-wrap">
<div class="recent-article-img">
<img class="img-fluid" src="image/blog-img-03.png" alt="">
<div class="publish-area d-xl-none d-flex">
<a href="blog-right-sidebar.php"><span>05</span>March</a>
</div>
</div>
 <div class="recent-article-content">
<div class="recent-article-meta">
<div class="publish-area">
<a href="blog-right-sidebar.php"><span>05</span>March</a>
</div>
<ul>
<li><a href="blog-right-sidebar.php"><img src="image/comment.svg" alt="">02 Comments</a></li>
<li><a href="blog-right-sidebar.php"><img src="image/user.svg" alt="">Mr. Jack Frank</a></li>
</ul>
</div>
<h4><a href="blog-details.php">How To Be Confident When Your Job Viva In Online, You Get To Know.</a></h4>
<div class="explore-btn">
<a href="blog-details.php"><span><img src="image/explore-elliose.svg" alt=""></span> Explore More</a>
</div>
</div>
</div>
</div>
<div class="col-md-6 col-sm-10 mb-20">
<div class="recent-article-wrap">
<div class="recent-article-img">
<img class="img-fluid" src="image/blog-img-04.png" alt="">
<div class="publish-area d-xl-none d-flex">
<a href="blog-right-sidebar.php"><span>08</span>April</a>
</div>
</div>
<div class="recent-article-content">
<div class="recent-article-meta">
<div class="publish-area">
<a href="blog-right-sidebar.php"><span>08</span>April</a>
</div>
<ul>
<li><a href="blog-right-sidebar.php"><img src="image/comment.svg" alt="">12 Comments</a></li>
<li><a href="blog-right-sidebar.php"><img src="image/user.svg" alt="">Mr. Jack Frank</a></li>
</ul>
</div>
<h4><a href="blog-details.php">To Find Out Your Job Location With Discussion Among Others.</a></h4>
<div class="explore-btn">
<a href="blog-details.php"><span><img src="image/explore-elliose.svg" alt=""></span> Explore More</a>
</div>
</div>
</div>
</div>
<div class="col-md-6 col-sm-10 mb-20">
<div class="recent-article-wrap">
<div class="recent-article-img">
<img class="img-fluid" src="image/blog-img-05.png" alt="">
<div class="publish-area d-xl-none d-flex">
<a href="blog-right-sidebar.php"><span>11</span>August</a>
</div>
</div>
<div class="recent-article-content">
<div class="recent-article-meta">
<div class="publish-area">
<a href="blog-right-sidebar.php"><span>11</span>August</a>
</div>
<ul>
 <li><a href="blog-right-sidebar.php"><img src="image/comment.svg" alt="">22 Comments</a></li>
<li><a href="blog-right-sidebar.php"><img src="image/user.svg" alt="">Mr. Jack Frank</a></li>
</ul>
</div>
<h4><a href="blog-details.php">Be Awareness Your Job Interviewing & Be Punctual Your Time.</a></h4>
<div class="explore-btn">
<a href="blog-details.php"><span><img src="image/explore-elliose.svg" alt=""></span> Explore More</a>
</div>
</div>
</div>
</div>
<div class="col-md-6 col-sm-10 mb-20">
<div class="recent-article-wrap">
<div class="recent-article-img">
<img class="img-fluid" src="image/blog-img-06.png" alt="">
<div class="publish-area d-xl-none d-flex">
<a href="blog-right-sidebar.php"><span>12</span>June</a>
</div>
</div>
<div class="recent-article-content">
<div class="recent-article-meta">
<div class="publish-area">
<a href="blog-right-sidebar.php"><span>12</span>June</a>
</div>
<ul>
<li><a href="blog-right-sidebar.php"><img src="image/comment.svg" alt="">07 Comments</a></li>
<li><a href="blog-right-sidebar.php"><img src="image/user.svg" alt="">Mr. Jack Frank</a></li>
</ul>
</div>
<h4><a href="blog-details.php">How To Improve Your Interview Question & Easy Answering Step By Step. </a></h4>
<div class="explore-btn">
<a href="blog-details.php"><span><img src="image/explore-elliose.svg" alt=""></span> Explore More</a>
</div>
</div>
</div>
</div>
<div class="col-lg-12 d-flex justify-content-center pt-20">
<div class="pagination-area">
<nav aria-label="...">
<ul class="pagination">
<li class="page-item disabled"><a class="page-link" href="#" tabindex="-1"></a></li>
<li class="page-item active" aria-current="page"><a class="page-link" href="#">01</a></li>
<li class="page-item"><a class="page-link" href="#">02</a></li>
<li class="page-item"><a class="page-link" href="#">03</a></li>
<li class="page-item"><a class="page-link" href="#"></a></li>
</ul>
</nav>
</div>
</div>
</div>
</div>
<div class="col-lg-4">
<div class="job-sidebar mb-50">
<div class="job-widget widget_search mb-20">
<form>
<div class="wp-block-search__inside-wrapper ">
<input type="search" id="wp-block-search__input-1" class="wp-block-search__input" name="s" value="" placeholder="Search Here" required="">
<button type="submit" class="wp-block-search__button">
<svg width="14" height="14" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
<path d="M7.10227 0.0713005C1.983 0.760967 -1.22002 5.91264 0.44166 10.7773C1.13596 12.8 2.60323 14.471 4.55652 15.4476C6.38483 16.3595 8.59269 16.5354 10.5737 15.9151C11.4023 15.6559 12.6011 15.0218 13.2121 14.5126L13.3509 14.3969L16.1281 17.1695C19.1413 20.1735 18.9932 20.0531 19.4237 19.9698C19.6505 19.9281 19.9282 19.6504 19.9699 19.4236C20.0532 18.9932 20.1735 19.1413 17.1695 16.128L14.397 13.3509L14.5127 13.212C14.7858 12.8834 15.2394 12.152 15.4755 11.6614C17.0029 8.48153 16.3271 4.74159 13.7814 2.28379C11.9994 0.561935 9.52304 -0.257332 7.10227 0.0713005ZM9.38418 1.59412C11.0135 1.9135 12.4669 2.82534 13.4666 4.15376C14.0591 4.94062 14.4572 5.82469 14.6793 6.83836C14.8136 7.44471 14.8228 8.75925 14.7025 9.34708C14.3507 11.055 13.4713 12.4622 12.1336 13.4666C11.3467 14.059 10.4627 14.4571 9.44898 14.6793C8.80097 14.8228 7.48644 14.8228 6.83843 14.6793C4.78332 14.2303 3.0985 12.9389 2.20054 11.1337C1.75156 10.2312 1.54328 9.43503 1.49699 8.4445C1.36276 5.62566 3.01055 3.05677 5.6535 1.96904C6.10248 1.7839 6.8014 1.59412 7.28741 1.52932C7.74102 1.46452 8.92595 1.50155 9.38418 1.59412Z"></path>
</svg>
</button>
</div>
</form>
</div>
<div class="job-widget style-1 mb-20">
<div class="check-box-item">
<h5 class="job-widget-title">Category</h5>
<div class="checkbox-container">
<ul>
<li>
<label class="containerss">
<input type="checkbox">
<span class="checkmark"></span>
<span class="text">Health Care</span>
<span class="qty">(10)</span>
</label>
</li>
<li>
<label class="containerss">
<input type="checkbox">
<span class="checkmark"></span>
<span class="text">Account & Finance</span>
<span class="qty">(05)</span>
</label>
</li>
<li>
<label class="containerss">
<input type="checkbox">
<span class="checkmark"></span>
<span class="text">Transportation</span>
<span class="qty">(08)</span>
</label>
</li>
<li>
<label class="containerss">
<input type="checkbox">
<span class="checkmark"></span>
<span class="text">Medical & Finance</span>
<span class="qty">(12)</span>
</label>
</li>
<li>
<label class="containerss">
<input type="checkbox">
<span class="checkmark"></span>
<span class="text">Development</span>
<span class="qty">(24)</span>
</label>
</li>
<li>
<label class="containerss">
<input type="checkbox">
<span class="checkmark"></span>
<span class="text">Engineering</span>
<span class="qty">(10)</span>
</label>
</li>
<li>
<label class="containerss">
<input type="checkbox">
<span class="checkmark"></span>
<span class="text">Receptionist</span>
<span class="qty">(20)</span>
</label>
</li>
<li>
<label class="containerss">
<input type="checkbox">
<span class="checkmark"></span>
<span class="text">Non-Profit Org.</span>
<span class="qty">(03)</span>
</label>
</li>
<li>
<label class="containerss">
<input type="checkbox">
<span class="checkmark"></span>
<span class="text">Health Care</span>
<span class="qty">(10)</span>
</label>
</li>
<li>
<label class="containerss">
<input type="checkbox">
<span class="checkmark"></span>
<span class="text">Account & Finance</span>
<span class="qty">(05)</span>
</label>
</li>
<li>
<label class="containerss">
<input type="checkbox">
<span class="checkmark"></span>
<span class="text">Transportation</span>
<span class="qty">(08)</span>
</label>
</li>
<li>
<label class="containerss">
<input type="checkbox">
<span class="checkmark"></span>
<span class="text">Medical & Finance</span>
<span class="qty">(12)</span>
</label>
</li>
</ul>
</div>
</div>
 </div>
<div class="job-widget mb-20">
<h5 class="job-widget-title mb-10">Recent Post</h5>
<ul class="recent-activitys">
<li>
<div class="blog-img">
<img src="image/blog-sb-1.png" alt="">
</div>
<div class="content">
<h6><a href="blog-details.php">To Make Your Smartness & Catch Your Dream.</a></h6>
<span><img src="image/calender2.svg" alt=""> 02 January, 2023</span>
</div>
</li>
<li>
<div class="blog-img">
<img src="image/blog-sb-2.png" alt="">
</div>
<div class="content">
<h6><a href="blog-details.php">Be Awareness Your Job Interviewing & Punctual.</a></h6>
<span><img src="image/calender2.svg" alt=""> 03 August, 2022</span>
</div>
</li>
<li>
<div class="blog-img">
<img src="image/blog-sb-3.png" alt="">
</div>
<div class="content">
<h6><a href="blog-details.php">There 20 Tips Of Trending UI/UX Design In 2023.</a></h6>
<span><img src="image/calender2.svg" alt=""> 02 January, 2023</span>
</div>
</li>
</ul>
</div>
<div class="job-widget">
<div class="check-box-item">
<h5 class="job-widget-title mb-10">Blog Tags</h5>
<ul class="tags">
<li><a href="blog-right-sidebar.php">Technology,</a></li>
<li><a href="blog-right-sidebar.php">Marketing,</a></li>
<li><a href="blog-right-sidebar.php">Sales,</a></li>
<li><a href="blog-right-sidebar.php">Transport,</a></li>
<li><a href="blog-right-sidebar.php">Medical,</a></li>
<li><a href="blog-right-sidebar.php">Design,</a></li>
<li><a href="blog-right-sidebar.php">Data Analyst,</a></li>
<li><a href="blog-right-sidebar.php">Development,</a></li>
<li><a href="blog-right-sidebar.php">Non-Profit,</a></li>
<li><a href="blog-right-sidebar.php">Manager,</a></li>
<li><a href="blog-right-sidebar.php">Health,</a></li>
</ul>
</div>
</div>
</div>
<div class="job-card">
<div class="job-content">
<h5>Hey! Do You Looking For Any Jobs?</h5>
<p>Job agencies may also offer additional services such as resume building.</p>
<div class="find-job-btn">
<a class="primry-btn-2 lg-btn " href="job-listing1.php">Find Job</a>
</div>
</div>
 <div class="job-img">
<img src="image/find-job.png" alt="">
</div>
</div>
</div>
</div>
</div>
</div>
<?php
include('footer.php');
?>