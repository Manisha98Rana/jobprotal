
<?php
    //   including the database connection file
    //     include("connect.php"); 

    //    Check If form submitted, insert user data into database.
    //     if (isset($_POST['register'])) {
    //         $fname     = $_POST['firstname1'];
    //         $lname     = $_POST['lastname1'];
    //         $uname     = $_POST['username'];
    //         $email    = $_POST['email'];
    //         $password = $_POST['password'];
    //         $confirmpassword = $_POST['confirmpassword'];                

    //         $sql="select * from register where (email='$email');";

    //         $res=mysqli_query($conn, $sql);

    //         if (mysqli_num_rows($res) > 0) {
                
    //             $row = mysqli_fetch_assoc($res);
    //             if($email==isset($row['email']))
    //             {
    //                 echo "<h1>email already exists</h1>";
    //                 header("Refresh:5; url=register.php");
    //             }
    //         } else {

    //        Insert user data into database
    //         $result   = mysqli_query($conn, "INSERT INTO register(firstname1,lastname1,username,email,password,confirmpassword) VALUES('$fname','$lname','$uname','$email','$password','$confirmpassword')");

    //        check if user data inserted successfully.
    //         if ($result) {
    //             echo "<br/><br/>User Registered successfully.";
    //             header("refresh:5; url=login.php");
    //         } else {
    //             echo "<script>Registration error. Please try again.<script>" . mysqli_error($conn);
    //         }
    //     }
    // }


  
session_start();

// initializing variables

$errors = array(); 

// connect to the database
include("connect.php"); 

// REGISTER USER
if (isset($_POST['register'])) {
  // receive all input values from the form
  $firstname1 = $_POST['firstname1'];
  $lastname1 = $_POST['lastname1'];
  $username = $_POST['username'];
  $email = $_POST['email'];
  $password = $_POST['password'];
  $confirmpassword = $_POST['confirmpassword'];

  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($firstname1)) { array_push($errors, "Firstname is required"); }
  if (empty($lastname1)) { array_push($errors, "Lastname is required"); }
  if (empty($username)) { array_push($errors, "Username is required"); }
  if (empty($email)) { array_push($errors, "Email is required"); }
  if (empty($password)) { array_push($errors, "Password is required"); }
  if ($password != $confirmpassword) {
	array_push($errors, "The two passwords do not match");
  }

  // first check the database to make sure 
  // a user does not already exist with the same username and/or email
  //$reg_profile = "SELECT reg.*,prof.data FROM register reg, my_profile prof WHERE reg.email=prof.email";
  $user_check_query = "SELECT * FROM register WHERE username='$username' OR email='$email' LIMIT 1";
  $result = mysqli_query($conn, $user_check_query);
  $user = mysqli_fetch_assoc($result);
  
  if ($user) { // if user exists
    if ($user['username'] === $username) {
      array_push($errors, "Username already exists");
    }

    if ($user['email'] === $email) {
      array_push($errors, "email already exists");
    }
  }

  // Finally, register user if there are no errors in the form
  if (count($errors) == 0) {
  	$password = md5($password);//encrypt the password before saving in the database
	  $confirmpassword = md5($confirmpassword);//encrypt the password before saving in the database

  	$query = mysqli_query($conn, "INSERT INTO register (firstname1, lastname1, username, email, password, confirmpassword) 
              VALUES('$firstname1','$lastname1','$username', '$email', '$password', '$confirmpassword')");

              mysqli_query($conn, "INSERT INTO my_profile (first_name, last_name, email) 
              VALUES('$firstname1','$lastname1','$username', '$email')"); 

    $num=mysqli_fetch_array($query);
          
  	//mysqli_query($conn, $query);
    if($num > 0)
    {
      $_SESSION['email'] = $email;
      $_SESSION['success'] = "You are now logged in";
      header('location: login.php');
    }
  }
}
// REGISTER COMPANY
if (isset($_POST['submit'])) {
  // receive all input values from the form
  $firstname = $_POST['firstname'];
  $lastname = $_POST['lastname'];
  $username = $_POST['username'];  
  $email = $_POST['email'];
  $companyname = $_POST['companyname'];
  $companytype = $_POST['companytype'];
  $password = $_POST['password'];
  $confirmpassword = $_POST['confirmpassword'];

  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($firstname)) { array_push($errors, "Firstname is required"); }
  if (empty($firstname)) { array_push($errors, "Lastname is required"); }
  if (empty($username)) { array_push($errors, "Username is required"); }
  if (empty($email)) { array_push($errors, "Email is required"); }
  if (empty($companyname)) { array_push($errors, "Companyname is required"); }
  if (empty($companytype)) { array_push($errors, "Companytype is required"); }
  if (empty($password)) { array_push($errors, "Password is required"); }
  if ($password != $confirmpassword) {
	array_push($errors, "The two passwords do not match");
  }

  // first check the database to make sure 
  // a user does not already exist with the same username and/or email
  $user_check_query = "SELECT * FROM company_register WHERE username='$username' OR email='$email' LIMIT 1";
  $result = mysqli_query($conn, $user_check_query);
  $user = mysqli_fetch_assoc($result);
  
  if ($user) { // if user exists
    if ($user['username'] === $username) {
      array_push($errors, "Username already exists");
    }

    if ($user['email'] === $email) {
      array_push($errors, "email already exists");
    }
  }

  // Finally, register user if there are no errors in the form
  if (count($errors) == 0) {
  	$password = md5($password);//encrypt the password before saving in the database
	$confirmpassword = md5($confirmpassword);//encrypt the password before saving in the database

  	$query = "INSERT INTO company_register (firstname, lastname, username, email, Companyname, password, confirmpassword) 
  			  VALUES('$firstname','$lastname','$username', '$email', '$Companyname', '$Companytype','$password', '$confirmpassword')";
  	mysqli_query($conn, $query);
  	$_SESSION['email'] = $email;
  	$_SESSION['success'] = "You are now logged in";
  	header('location: login.php');
  }
}


// LOGIN USER / COMPANY
if (isset($_POST['login'])) {
  $email = mysqli_real_escape_string($conn, $_POST['email']);
  $password = mysqli_real_escape_string($conn, $_POST['password']);

  if (empty($email)) {
  	array_push($errors, "Email is required");
  }
  if (empty($password)) {
  	array_push($errors, "Password is required");
  }

  if (count($errors) == 0) {
  	$password = md5($password);
  	$query = "SELECT * FROM register WHERE  email='$email' AND password='$password'";
  	$results = mysqli_query($conn, $query);
  	if (!$results || mysqli_num_rows($results) == 1) {          
        $_SESSION['email'] = $email;
  	    $_SESSION['success'] = "You are now logged in";
  	  header('location: user-dashboard.php');
  	}else {
  		array_push($errors, "Wrong email/password combination");
  	}
  }
}

 ?>
