<?php
	 header( "refresh:5;url=login.php" );

     // $servername => localhost
     // $username => root
     // $password => empty
     // $database name => demo
     $conn = mysqli_connect("localhost", "root", "", "vacancy4all-");
      
     // Check connection
     if($conn === false){
         die("ERROR: Could not connect. "
             . mysqli_connect_error());
     }
     
     //Table Create
    //   $sql = "create table Register2(id INT AUTO_INCREMENT PRIMARY KEY,firstname1 VARCHAR(200) NOT NULL,lastname1 VARCHAR(200) NOT NULL,username VARCHAR(200) NOT NULL,email VARCHAR(200) NOT NULL,password VARCHAR(50) NOT NULL)";  
    //   if(mysqli_query($conn, $sql)){  
    //    echo "Table Register2 created successfully";  
    //   }else{  
    //   echo "Could not create table: ". mysqli_error($conn);  
    //   }  
     
     // Taking all 5 values from the form data(input)
     $userid = $_REQUEST['id'];
     $firstname =  $_REQUEST['firstname1'];
     $lastname = $_REQUEST['lastname1'];
     $username = $_REQUEST['username'];
     $email = $_REQUEST['email'];
     $passowrd = $_REQUEST['password'];

      
     // Performing insert query execution
     // here our table name is college
     $sql = "INSERT INTO Register2  VALUES ('$userid','$firstname',
         '$lastname','$username','$email','$passowrd')";
      
     if(mysqli_query($conn, $sql)){
         echo "<h3>data stored in a database successfully."
             . " Please browse your localhost php my admin"
             . " to view the updated data</h3>";

         echo nl2br("\n$userid\n $firstname\n $lastname\n $username\n $email\n $passowrd\n");
     } else{
         echo "ERROR: Hush! Sorry $sql. "
             . mysqli_error($conn);
     }
      
     // Close connection
     mysqli_close($conn);
 ?>