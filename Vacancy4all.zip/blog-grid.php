<?php
include('header2.php');
?>
<div class="inner-banner">
<div class="container">
<div class="row">
<div class="col-lg-12">
<div class="banner-content text-center">
<h1>Blog</h1>
<span></span>
<nav aria-label="breadcrumb">
<ol class="breadcrumb">
<li class="breadcrumb-item"><a href="home.php">Home</a></li>
<li class="breadcrumb-item active" aria-current="page">Blog</li>
</ol>
</nav>
</div>
</div>
</div>
</div>
</div>


<div class="blog-grid-area pt-120 mb-120">
<div class="container">
<div class="row g-lg-4 gy-5 justify-content-center">
<div class="col-lg-4 col-md-6 col-sm-10 mb-20">
<div class="recent-article-wrap">
<div class="recent-article-img">
<img class="img-fluid" src="image/blog-img-01.png" alt="">
<div class="publish-area d-xl-none d-flex">
<a href="blog-grid.php"><span>02</span>March</a>
 </div>
</div>
<div class="recent-article-content">
<div class="recent-article-meta">
<div class="publish-area">
<a href="blog-grid.php"><span>02</span>March</a>
</div>
<ul>
<li><a href="blog-grid.php"><img src="image/comment.svg" alt="">03 Comments</a></li>
<li><a href="blog-grid.php"><img src="image/user.svg" alt="">Mr. Jack Frank</a></li>
</ul>
</div>
<h4><a href="blog-details.php">To Make Your Smartness &amp; Catch
Your Bright Dream.</a></h4>
<div class="explore-btn">
<a href="blog-details.php"><span><img src="image/explore-elliose.svg" alt=""></span> Explore More</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 col-sm-10 mb-20">
<div class="recent-article-wrap">
<div class="recent-article-img">
<img class="img-fluid" src="image/blog-img-02.png" alt="">
<div class="publish-area d-xl-none d-flex">
<a href="blog-grid.php"><span>04</span>March</a>
</div>
</div>
<div class="recent-article-content">
<div class="recent-article-meta">
<div class="publish-area">
<a href="blog-grid.php"><span>04</span>March</a>
</div>
<ul>
<li><a href="blog-grid.php"><img src="image/comment.svg" alt="">11 Comments</a></li>
<li><a href="blog-grid.php"><img src="image/user.svg" alt="">Mr. Jack Frank</a></li>
</ul>
</div>
<h4><a href="blog-details.php">Be Confident Your Dream & Struggle
About Your Bright Dream.</a></h4>
<div class="explore-btn">
<a href="blog-details.php"><span><img src="image/explore-elliose.svg" alt=""></span> Explore More</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 col-sm-10 mb-20">
<div class="recent-article-wrap">
<div class="recent-article-img">
<img class="img-fluid" src="image/blog-img-03.png" alt="">
<div class="publish-area d-xl-none d-flex">
<a href="blog-grid.php"><span>05</span>March</a>
</div>
</div>
<div class="recent-article-content">
<div class="recent-article-meta">
<div class="publish-area">
<a href="blog-grid.php"><span>05</span>March</a>
</div>
<ul>
<li><a href="blog-grid.php"><img src="image/comment.svg" alt="">02 Comments</a></li>
<li><a href="blog-grid.php"><img src="image/user.svg" alt="">Mr. Jack Frank</a></li>
</ul>
</div>
 <h4><a href="blog-details.php">How To Be Confident When Your Job Viva In Online, You Get To Know.</a></h4>
<div class="explore-btn">
<a href="blog-details.php"><span><img src="image/explore-elliose.svg" alt=""></span> Explore More</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 col-sm-10 mb-20">
<div class="recent-article-wrap">
<div class="recent-article-img">
<img class="img-fluid" src="image/blog-img-04.png" alt="">
<div class="publish-area d-xl-none d-flex">
<a href="blog-grid.php"><span>08</span>April</a>
</div>
</div>
<div class="recent-article-content">
<div class="recent-article-meta">
<div class="publish-area">
<a href="blog-grid.php"><span>08</span>April</a>
</div>
<ul>
<li><a href="blog-grid.php"><img src="image/comment.svg" alt="">12 Comments</a></li>
<li><a href="blog-grid.php"><img src="image/user.svg" alt="">Mr. Jack Frank</a></li>
</ul>
</div>
<h4><a href="blog-details.php">To Find Out Your Job Location With Discussion Among Others.</a></h4>
<div class="explore-btn">
<a href="blog-details.php"><span><img src="image/explore-elliose.svg" alt=""></span> Explore More</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 col-sm-10 mb-20">
<div class="recent-article-wrap">
<div class="recent-article-img">
<img class="img-fluid" src="image/blog-img-05.png" alt="">
<div class="publish-area d-xl-none d-flex">
<a href="blog-grid.php"><span>11</span>August</a>
</div>
</div>
<div class="recent-article-content">
<div class="recent-article-meta">
<div class="publish-area">
<a href="blog-grid.php"><span>11</span>August</a>
</div>
<ul>
<li><a href="blog-grid.php"><img src="image/comment.svg" alt="">22 Comments</a></li>
<li><a href="blog-grid.php"><img src="image/user.svg" alt="">Mr. Jack Frank</a></li>
</ul>
</div>
<h4><a href="blog-details.php">Be Awareness Your Job Interviewing & Be Punctual Your Time.</a></h4>
<div class="explore-btn">
<a href="blog-details.php"><span><img src="image/explore-elliose.svg" alt=""></span> Explore More</a>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 col-sm-10 mb-20">
<div class="recent-article-wrap">
<div class="recent-article-img">
<img class="img-fluid" src="image/blog-img-06.png" alt="">
<div class="publish-area d-xl-none d-flex">
<a href="blog-grid.php"><span>12</span>June</a>
</div>
</div>
<div class="recent-article-content">
<div class="recent-article-meta">
<div class="publish-area">
<a href="blog-grid.php"><span>12</span>June</a>
</div>
<ul>
<li><a href="blog-grid.php"><img src="image/comment.svg" alt="">07 Comments</a></li>
<li><a href="blog-grid.php"><img src="image/user.svg" alt="">Mr. Jack Frank</a></li>
</ul>
</div>
<h4><a href="blog-details.php">How To Improve Your Interview Question & Easy Answering Step By Step. </a></h4>
<div class="explore-btn">
<a href="blog-details.php"><span><img src="image/explore-elliose.svg" alt=""></span> Explore More</a>
</div>
</div>
</div>
</div>
<div class="col-lg-12 d-flex justify-content-center pt-20">
<div class="pagination-area">
<nav aria-label="...">
<ul class="pagination">
<li class="page-item disabled"><a class="page-link" href="#" tabindex="-1"></a></li>
<li class="page-item active" aria-current="page"><a class="page-link" href="#">01</a></li>
<li class="page-item"><a class="page-link" href="#">02</a></li>
<li class="page-item"><a class="page-link" href="#">03</a></li>
<li class="page-item"><a class="page-link" href="#"></a></li>
</ul>
</nav>
</div>
</div>
</div>
</div>
</div>
<?php
include('footer.php');
?>